This init_states folder is to contain all the csv files pertaining to the project.

The purpose of this is like a back-up.
If the application happens to the fail,
and the application did not manage to even
write lines to the csv file on abrupt shutdown,
use the files in this folder, 
and copy-paste over the the files in the previous directory.